# Copyright (c) OpenMMLab. All rights reserved.
import os
import os.path as osp
import tempfile
from argparse import ArgumentParser

import mmcv

import sys
pwd = os.path.abspath(os.getcwd())
sys.path.append(pwd)

from mmtrack.apis import inference_vid, init_model

import cv2
import numpy as np
import torch

from mmdet.apis import (async_inference_detector, inference_detector,
                        init_detector, show_result_pyplot)




_COCO_CATEGORIES = [
    "person",
    "bicycle",
    "car",
    "motorcycle",
    "airplane",
    "bus",
    "train",
    "truck",
    "boat",
    "traffic light",
    "fire hydrant",
    "N/A",
    "stop sign",
    "parking meter",
    "bench",
    "bird",
    "cat",
    "dog",
    "horse",
    "sheep",
    "cow",
    "elephant",
    "bear",
    "zebra",
    "giraffe",
    "N/A",
    "backpack",
    "umbrella",
    "N/A",
    "N/A",
    "handbag",
    "tie",
    "suitcase",
    "frisbee",
    "skis",
    "snowboard",
    "sports ball",
    "kite",
    "baseball bat",
    "baseball glove",
    "skateboard",
    "surfboard",
    "tennis racket",
    "bottle",
    "N/A",
    "wine glass",
    "cup",
    "fork",
    "knife",
    "spoon",
    "bowl",
    "banana",
    "apple",
    "sandwich",
    "orange",
    "broccoli",
    "carrot",
    "hot dog",
    "pizza",
    "donut",
    "cake",
    "chair",
    "couch",
    "potted plant",
    "bed",
    "N/A",
    "dining table",
    "N/A",
    "N/A",
    "toilet",
    "N/A",
    "tv",
    "laptop",
    "mouse",
    "remote",
    "keyboard",
    "cell phone",
    "microwave",
    "oven",
    "toaster",
    "sink",
    "refrigerator",
    "N/A",
    "book",
    "clock",
    "vase",
    "scissors",
    "teddy bear",
    "hair drier",
    "toothbrush",
]




def get_instance_mask(model, image):
    # test a single image, image can be path or np.array bgr
    result = inference_detector(model, image)  # Format bbox and mask results.
    print('=====')
    
    instance_mask_cat_list = []

    global_instance_id = 0
    for cat_idx, dets in enumerate(result[0]):
        if cat_idx != 0: continue
        if len(dets) != 0:
            cur_cat_masks = result[1][cat_idx]
            ### log
            num_valid_instance = 0
            ### cur category valid instance （score > 0.3）
            for instance_idx, bbox in enumerate(dets):
                score = bbox[4]
                if score > 0.3:
                    cur_instance_mask = cur_cat_masks[instance_idx].astype(np.int)  # {0,1}, h*w
                    ###
                    cur_instance_mask_cat = (global_instance_id, cat_idx, score, cur_instance_mask)
                    instance_mask_cat_list.append(cur_instance_mask_cat)

                    global_instance_id += 1
                    ### log
                    num_valid_instance += 1

            if num_valid_instance != 0:
                print('>> This image category', _COCO_CATEGORIES[cat_idx], ': has', num_valid_instance, 'instances')
                ####

    all_instance_mask = 0
    for instance_id, tup in enumerate(instance_mask_cat_list):
        all_instance_mask += tup[-1] * (instance_id + 1)
    ##### 像素值表示 instance id，不考虑重叠的情况, h*w
    return all_instance_mask



def get_instance_mask_from_point(xy, mask):
    instance = np.zeros_like(mask)
    instance[xy[0], xy[1]] = 1
    instance = instance * mask
    instance_id = instance[xy[0], xy[1]]
    instance_id = int(instance_id)
    return instance_id




    





def main():
    parser = ArgumentParser()
    parser.add_argument('--config', default='/home/lyx_zy/our_code/yixinghuanying/mmtracking/demo/config.py', help='Config file')

    parser.add_argument('--input', default='/home/lyx_zy/our_code/yixinghuanying/demo_cai.mp4', help='输入video文件')
    parser.add_argument('--output', default='/home/lyx_zy/our_code/yixinghuanying/demo_tracking.mp4', help='输出video文件')

    ## tracking 模型：https://download.openmmlab.com/mmtracking/mot/bytetrack/bytetrack_yolox_x/bytetrack_yolox_x_crowdhuman_mot17-private-half_20211218_205500-1985c9f0.pth
    parser.add_argument('--checkpoint', default='/home/lyx_zy/our_code/yixinghuanying/bytetrack_yolox_x_crowdhuman_mot17.pth', help='Checkpoint file')
    
    parser.add_argument(
        '--device', default='cuda:0', help='Device used for inference')
    parser.add_argument(
        '--show',
        action='store_true',
        default=False,
        help='whether to show visualizations.')
    parser.add_argument(
        '--score-thr', type=float, default=0.8, help='bbox score threshold')
    parser.add_argument(
        '--thickness', default=3, type=int, help='Thickness of bbox lines.')
    parser.add_argument('--fps', help='FPS of the output video')
    args = parser.parse_args()

    seg_model = init_detector('/home/lyx_zy/our_code/yixinghuanying/mmtracking/demo/solov2_r50_fpn.py', ## 分割模型配置文件
                            '/home/lyx_zy/our_code/yixinghuanying/mmdet_3rd_party/solov2_r50_fpn_3x_coco.pth',  # 分割模型
                            device='cuda:0')

    # load images
    if osp.isdir(args.input):
        imgs = sorted(
            filter(lambda x: x.endswith(('.jpg', '.png', '.jpeg')),
                   os.listdir(args.input)),
            key=lambda x: int(x.split('.')[0]))
        IN_VIDEO = False
    else:
        imgs = mmcv.VideoReader(args.input)
        IN_VIDEO = True

    # define output
    if args.output is not None:
        if args.output.endswith('.mp4'):
            OUT_VIDEO = True
            out_dir = tempfile.TemporaryDirectory()
            out_path = out_dir.name
            _out = args.output.rsplit(os.sep, 1)
            if len(_out) > 1:
                os.makedirs(_out[0], exist_ok=True)
        else:
            OUT_VIDEO = False
            out_path = args.output
            os.makedirs(out_path, exist_ok=True)

    fps = args.fps
    if args.show or OUT_VIDEO:
        if fps is None and IN_VIDEO:
            fps = imgs.fps
        if not fps:
            raise ValueError('Please set the FPS for the output video.')
        fps = int(fps)

    # build the model from a config file and a checkpoint file
    model = init_model(args.config, args.checkpoint, device=args.device)

    ### first frame
    

    img = imgs[0]
    xy = (img.shape[1]//2, img.shape[0]//2)
    result = inference_vid(model, img, frame_id=0)
    result = result['track_bboxes'][0]
    print(result)
    n_obj = result.shape[0]
    tar_id = -1
    for idx in range(n_obj):
        bbx = result[idx]
        if bbx[1] < xy[0] < bbx[3] and bbx[2] < xy[1] < bbx[4]:
            tar_id = bbx[0]
            tar_id = int(tar_id)
            break
    assert tar_id != -1
    print('target obj id', int(tar_id))
    ###

    prog_bar = mmcv.ProgressBar(len(imgs))
    # test and show/save the images
    for i, img in enumerate(imgs):
        if isinstance(img, str):
            img = osp.join(args.input, img)
            img = mmcv.imread(img)

        # print(img)
        result = inference_vid(model, img, frame_id=i)
        # instance_mask = get_instance_mask(seg_model, img)
        print('=====')
        # print(result['track_bboxes'][0])  # n_obj x 6: id, x, y, x, y, score
        bboxes = result['track_bboxes'][0]
        print('=====')
        h, w, c = img.shape
        tar_bbx = None
        for idx in range(bboxes.shape[0]):
            bbox = bboxes[idx]
            # print(int(bbox[0]), tar_id, int(bbox[0])==tar_id)
            if int(bbox[0]) == tar_id:
                tar_bbx = bbox[1: 5]
                break
        assert tar_bbx is not None

        x1, y1, x2, y2 = tar_bbx[0: 4]
        bx_w = x2 - x1
        bx_h = y2 - y1
        x1 = x1 - bx_w // 5
        if x1 < 0: x1 = 0
        x2 = x2 + bx_w // 5
        if x2 >= w: x2 = w-1
        y1 = y1 - bx_h // 5
        if y1 < 0: y1 = 0
        y2 = y2 + bx_h // 5
        if y2 >= h: y2 = h-1
        x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)

        bbox_mask = np.zeros_like(img)
        bbox_mask[y1: y2, x1: x2, :] = 1
        img = img * bbox_mask

        instance_mask = get_instance_mask(seg_model, img)
        uniq = np.unique(instance_mask)
        max_value = 0
        max_length = 0
        for value in uniq:
            length = np.argwhere(instance_mask == value).shape[0]
            if length > max_length and value != 0:
                max_length = length
                max_value = value

        instance_mask[instance_mask != max_value] = 0
        instance_mask[instance_mask == max_value] = 1

        img = img * np.expand_dims(instance_mask, -1).astype('uint8')

        #### save results
        if args.output is not None:
            if IN_VIDEO or OUT_VIDEO:
                out_file = osp.join(out_path, f'{i:06d}.jpg')
            else:
                out_file = osp.join(out_path, img.rsplit(os.sep, 1)[-1])
        else:
            out_file = None
        model.show_result(
            img,
            result,
            score_thr=args.score_thr,
            show=args.show,
            wait_time=int(1000. / fps) if fps else 0,
            out_file=out_file,
            thickness=args.thickness)
        prog_bar.update()

    if args.output and OUT_VIDEO:
        print(
            f'\nmaking the output video at {args.output} with a FPS of {fps}')
        mmcv.frames2video(out_path, args.output, fps=fps, fourcc='mp4v')
        out_dir.cleanup()


if __name__ == '__main__':
    main()
