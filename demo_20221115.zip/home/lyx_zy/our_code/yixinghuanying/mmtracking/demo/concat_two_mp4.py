import numpy as np
import cv2
import os


def read_vid(vid_url):
    cap = cv2.VideoCapture(vid_url)
    fps = cap.get(cv2.CAP_PROP_FPS)
    print('##### fps={}'.format(fps))
    count = 0
    frames = []
    while cap.isOpened():
        _, img = cap.read()
        if img is None:
            break
        frames.append(img)
        count += 1
    cap.release()
    return frames


def writer(frames, vid_path, fps):
    w = frames[0].shape[1]
    h = frames[0].shape[0]
    size = (w, h)
    writer = cv2.VideoWriter(vid_path, cv2.VideoWriter_fourcc(*"mp4v"),
                            fps, size)
    for f in range(len(frames)):
        comp = frames[f].astype(np.uint8)
        writer.write(comp)
    writer.release()


def concat(video1, video2):
    h1, w1, c = video2[0].shape
    h2, w2, c = video1[0].shape
    h = max(h1, h2)
    w = max(w1, w2)
    new = []
    for x in video1:
        x = cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR)
        new.append(x)

    for alpha in range(1, 101):
        video1[-1] = cv2.resize(video1[-1], (w, h), interpolation=cv2.INTER_LINEAR)
        # video2[alpha] = cv2.resize(video2[0], (w, h), interpolation=cv2.INTER_LINEAR)
        x = cv2.resize(video2[alpha-1], (w, h), interpolation=cv2.INTER_LINEAR)
        # print(video1[-1].max(), video1[-1].min(), video2[0].max(), video2[0].min())

        alpha = alpha / 100
        new_frame = video1[-1] * (1 - alpha) + x * alpha

        new_frame = new_frame * 255 // 255
        print(new_frame.max(), new_frame.min())
        new.append(new_frame)

    for x in video2[100:]:
        x = cv2.resize(x, (w, h))
        new.append(x)
    return new


def merge(video1, video2):
    length = len(video1)
    print(length)
    h1, w1, c = video2[0].shape
    h2, w2, c = video1[0].shape
    h = min(h1, h2)
    w = min(w1, w2)
    new = []
    for x in video1[: length//3-25]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    for alpha in range(1, 51):
        frame1 = video1[length//3-25+alpha-1]
        frame2 = video2[length//3-25+alpha-1]
        frame1 = cv2.resize(frame1, (w, h), interpolation=cv2.INTER_LINEAR)
        frame2 = cv2.resize(frame2, (w, h), interpolation=cv2.INTER_LINEAR)
        alpha = alpha / 50
        x = frame1 * (1 - alpha) + frame2 * alpha
        new.append(x)
    for x in video2[length//3+25: length*2//3-25]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    for alpha in range(1, 51):
        frame1 = video2[length*2//3-25+alpha-1]
        frame2 = video1[length*2//3-25+alpha-1]
        frame1 = cv2.resize(frame1, (w, h), interpolation=cv2.INTER_LINEAR)
        frame2 = cv2.resize(frame2, (w, h), interpolation=cv2.INTER_LINEAR)
        alpha = alpha / 50
        x = frame1 * (1 - alpha) + frame2 * alpha
        new.append(x)
    for x in video1[length*2//3+25:]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    return new



def merge_v2(video1, video2):
    length = len(video1)
    print(length)
    h1, w1, c = video2[0].shape
    h2, w2, c = video1[0].shape
    h = min(h1, h2)
    w = min(w1, w2)
    new = []
    for x in video1[: length//2-50]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    for alpha in range(1, 101):
        frame1 = video1[length//2-50+alpha-1]
        frame2 = video2[length//2-50+alpha-1]
        frame1 = cv2.resize(frame1, (w, h), interpolation=cv2.INTER_LINEAR)
        frame2 = cv2.resize(frame2, (w, h), interpolation=cv2.INTER_LINEAR)
        alpha = alpha / 100
        x = frame1 * (1 - alpha) + frame2 * alpha
        new.append(x)
    for x in video2[length//2+50:]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    return new


def merge_v3(video1, video2):
    video1 = video1[:len(video2)]
    length = len(video1)
    print(length)
    h1, w1, c = video2[0].shape
    h2, w2, c = video1[0].shape
    h = min(h1, h2)
    w = min(w1, w2)
    new = []
    for x in video1[: length//3-15]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    for alpha in range(1, 31):
        frame1 = video1[length//3-15+alpha-1]
        frame2 = video2[length//3-15+alpha-1]
        frame1 = cv2.resize(frame1, (w, h), interpolation=cv2.INTER_LINEAR)
        frame2 = cv2.resize(frame2, (w, h), interpolation=cv2.INTER_LINEAR)
        alpha = alpha / 30
        x = frame1 * (1 - alpha) + frame2 * alpha
        new.append(x)
    for x in video2[length//3+15: length*2//3-15]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    for alpha in range(1, 31):
        frame1 = video2[length*2//3-15+alpha-1]
        frame2 = video1[length*2//3-15+alpha-1]
        frame1 = cv2.resize(frame1, (w, h), interpolation=cv2.INTER_LINEAR)
        frame2 = cv2.resize(frame2, (w, h), interpolation=cv2.INTER_LINEAR)
        alpha = alpha / 30
        x = frame1 * (1 - alpha) + frame2 * alpha
        new.append(x)
    for x in video1[length*2//3+15:]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    return new




def merge_v4(video1, video2):
    video1 = video1[:len(video2)]
    length = len(video1)
    print(length)
    h1, w1, c = video2[0].shape
    h2, w2, c = video1[0].shape
    h = min(h1, h2)
    w = min(w1, w2)
    new = []
    for x in video1[: length//3-15]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    for alpha in range(1, 31):
        frame1 = video1[length//3-15+alpha-1]
        frame2 = video2[length//3-15+alpha-1]
        frame1 = cv2.resize(frame1, (w, h), interpolation=cv2.INTER_LINEAR)
        frame2 = cv2.resize(frame2, (w, h), interpolation=cv2.INTER_LINEAR)
        alpha = alpha / 30
        x = frame1 * (1 - alpha) + frame2 * alpha
        new.append(x)
    for x in video2[length//3+15: length*3//3-15]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    for alpha in range(1, 11):
        frame1 = video2[length*3//3-15+alpha-1]
        frame2 = video1[length*3//3-15+alpha-1]
        frame1 = cv2.resize(frame1, (w, h), interpolation=cv2.INTER_LINEAR)
        frame2 = cv2.resize(frame2, (w, h), interpolation=cv2.INTER_LINEAR)
        alpha = alpha / 10
        x = frame1 * (1 - alpha) + frame2 * alpha
        new.append(x)
    for x in video1[length*3//3-5:]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    return new




def merge_v5(video1, video2):
    video1 = video1[:len(video2)]
    length = len(video1)
    print(length)
    h1, w1, c = video2[0].shape
    h2, w2, c = video1[0].shape
    h = min(h1, h2)
    w = min(w1, w2)
    new = []
    for x in video1[: length//4-15]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    for alpha in range(1, 31):
        frame1 = video1[length//4-15+alpha-1]
        frame2 = video2[length//4-15+alpha-1]
        frame1 = cv2.resize(frame1, (w, h), interpolation=cv2.INTER_LINEAR)
        frame2 = cv2.resize(frame2, (w, h), interpolation=cv2.INTER_LINEAR)
        alpha = alpha / 30
        x = frame1 * (1 - alpha) + frame2 * alpha
        new.append(x)
    for x in video2[length//4+15: length*2//4-15]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    for alpha in range(1, 31):
        frame1 = video2[length*2//4-15+alpha-1]
        frame2 = video1[length*2//4-15+alpha-1]
        frame1 = cv2.resize(frame1, (w, h), interpolation=cv2.INTER_LINEAR)
        frame2 = cv2.resize(frame2, (w, h), interpolation=cv2.INTER_LINEAR)
        alpha = alpha / 30
        x = frame1 * (1 - alpha) + frame2 * alpha
        new.append(x)
    for x in video1[length*2//4+15:]:
        new.append(cv2.resize(x, (w, h), interpolation=cv2.INTER_LINEAR))
    return new


        

video1 = '/home/lyx_zy/our_code/yixinghuanying/mmtracking/video/5_cut.mp4'
video2 = '/home/lyx_zy/our_code/yixinghuanying/mmtracking/results/5_cut_results.mp4'
video_path = '/home/lyx_zy/our_code/yixinghuanying/mmtracking/video/5_cut_concat.mp4'

video1 = read_vid(video1)
video2 = read_vid(video2)

# length = len(video1)

# part1 = video1[0:length//3]
# part2 = video2[length//3: length*2//3]
# part3 = video1[length*2//3:]

# video = concat(part1, part2)
# video = concat(video, part3)

video = merge_v5(video1, video2)

# video = video[50: -100]


writer(video, video_path, 30)
