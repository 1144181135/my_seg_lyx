
from email.mime import image
from glob import glob
import torch.utils.data as data
import os
import cv2
from PIL import Image, ImageFilter
from utils import preprocess
import random
import torch
import numpy as np
from torchvision import transforms



class GaussianBlur(object):
    """Gaussian blur augmentation in SimCLR https://arxiv.org/abs/2002.05709"""

    def __init__(self, sigma=[.1, 2.]):
        self.sigma = sigma

    def __call__(self, x):
        sigma = random.uniform(self.sigma[0], self.sigma[1])
        x = x.filter(ImageFilter.GaussianBlur(radius=sigma))
        return x



class zengyi_seg(data.Dataset):
    def __init__(self, image_dir, mask_dir, split='train', transform=None):
        self.image_dir = image_dir
        self.mask_dir = mask_dir
        self.split = split

        self.transform = transform

        names = os.listdir(image_dir)
        samples = []
        for i in names:
            samples.append(i.split('.')[0])
        self.samples = samples


    def __getitem__(self, idx):
        image = os.path.join(self.image_dir, self.samples[idx]+'.jpg')
        mask = os.path.join(self.mask_dir, self.samples[idx]+'.png')

        image = Image.open(image).convert('RGB')
        mask = Image.open(mask).convert('L')

        image = self.transform(image)
        mask = np.array(mask) / 255
        mask = torch.from_numpy(mask).long()

        return image, mask


    def __len__(self):
        return len(self.samples)


