def SPDNorm():
    return None
