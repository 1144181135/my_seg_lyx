# Copyright (c) OpenMMLab. All rights reserved.
import cv2
import numpy as np
import torch

from mmdet.apis import (async_inference_detector, inference_detector,
                        init_detector, show_result_pyplot)

import os
from config.test_config import TestConfig

basic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__)))
import sys

sys.path.append(basic_dir)
import util.util as util
from models.models import create_model


_COCO_CATEGORIES = [
    "person",
    "bicycle",
    "car",
    "motorcycle",
    "airplane",
    "bus",
    "train",
    "truck",
    "boat",
    "traffic light",
    "fire hydrant",
    "N/A",
    "stop sign",
    "parking meter",
    "bench",
    "bird",
    "cat",
    "dog",
    "horse",
    "sheep",
    "cow",
    "elephant",
    "bear",
    "zebra",
    "giraffe",
    "N/A",
    "backpack",
    "umbrella",
    "N/A",
    "N/A",
    "handbag",
    "tie",
    "suitcase",
    "frisbee",
    "skis",
    "snowboard",
    "sports ball",
    "kite",
    "baseball bat",
    "baseball glove",
    "skateboard",
    "surfboard",
    "tennis racket",
    "bottle",
    "N/A",
    "wine glass",
    "cup",
    "fork",
    "knife",
    "spoon",
    "bowl",
    "banana",
    "apple",
    "sandwich",
    "orange",
    "broccoli",
    "carrot",
    "hot dog",
    "pizza",
    "donut",
    "cake",
    "chair",
    "couch",
    "potted plant",
    "bed",
    "N/A",
    "dining table",
    "N/A",
    "N/A",
    "toilet",
    "N/A",
    "tv",
    "laptop",
    "mouse",
    "remote",
    "keyboard",
    "cell phone",
    "microwave",
    "oven",
    "toaster",
    "sink",
    "refrigerator",
    "N/A",
    "book",
    "clock",
    "vase",
    "scissors",
    "teddy bear",
    "hair drier",
    "toothbrush",
]



def get_instance_mask(model, image):
    # test a single image, image can be path or np.array bgr
    result = inference_detector(model, image)  # Format bbox and mask results.
    print('=====')
    
    instance_mask_cat_list = []

    global_instance_id = 0
    for cat_idx, dets in enumerate(result[0]):
        if len(dets) != 0:
            cur_cat_masks = result[1][cat_idx]
            ### log
            num_valid_instance = 0
            ### cur category valid instance （score > 0.3）
            for instance_idx, bbox in enumerate(dets):
                score = bbox[4]
                if score > 0.3:
                    cur_instance_mask = cur_cat_masks[instance_idx].astype(np.int)  # {0,1}, h*w
                    ###
                    cur_instance_mask_cat = (global_instance_id, cat_idx, score, cur_instance_mask)
                    instance_mask_cat_list.append(cur_instance_mask_cat)

                    global_instance_id += 1
                    ### log
                    num_valid_instance += 1

            if num_valid_instance != 0:
                print('>> This image category', _COCO_CATEGORIES[cat_idx], ': has', num_valid_instance, 'instances')
                ####

    for i in range(len(instance_mask_cat_list)):
        print(np.argwhere(instance_mask_cat_list[i][-1]==1)[0])

    all_instance_mask = 0
    for instance_id, tup in enumerate(instance_mask_cat_list):
        all_instance_mask += tup[-1] * (instance_id + 1)
    ##### 像素值表示 instance id，不考虑重叠的情况, h*w
    return all_instance_mask



def get_instance_mask_from_point(xy, mask):
    instance = np.zeros_like(mask)  # h, w
    instance[xy[1], xy[0]] = 1
    instance = instance * mask
    instance_id = instance[xy[1], xy[0]]
    instance_id = int(instance_id)
    return instance_id




if __name__ == '__main__':
    img_path = '/home/lyx_zy/our_code/yixinghuanying/cityscape_car.jpeg'
    seg_res_path = '/home/lyx_zy/our_code/yixinghuanying/cityscape_car_seg.png'
    image_with_mask_path = '/home/lyx_zy/our_code/yixinghuanying/cityscape_car_with_mask.png'
    inpainting_res_path = '/home/lyx_zy/our_code/yixinghuanying/cityscape_car_inpaint.png'

    cfg_path = 'solov2_r50_fpn.py'
    ## model_path download: https://download.openmmlab.com/mmdetection/v2.0/solov2/solov2_r50_fpn_3x_coco/solov2_r50_fpn_3x_coco_20220512_125856-fed092d4.pth
    model_path = '/home/lyx_zy/our_code/yixinghuanying/mmdet_3rd_party/solov2_r50_fpn_3x_coco.pth'
    device = 'cuda:0'
    tar_size = (256*3, 256*3)

    ### inpaiting
    cfg = TestConfig().create_config()
    ####
    cfg.model = 'PConv'

    xy = (688, 420)   # w, h
    tar_xy = (300, 300)

    seg_model = init_detector(cfg_path, model_path, device=device)
    inpainting_model = create_model(cfg)

    image = cv2.imread(img_path)
    instance_mask = get_instance_mask(seg_model, image)
    instance_id = get_instance_mask_from_point(xy, instance_mask)

    instance_mask[instance_mask != instance_id] = 0
    instance_mask[instance_mask == instance_id] = 1

    cv2.imwrite(seg_res_path, instance_mask*255)

    ## 把前景抠掉
    image = image[:, :, ::-1].copy()  # bgr -> rgb
    print(image.shape)
    image = torch.from_numpy(image).to(device).permute(2, 0, 1).unsqueeze(0).float()  # 1, c, h, w
    ori_h, ori_w = image.shape[2:]
    image = torch.nn.functional.interpolate(image, tar_size, mode='bilinear')
    image = (image / 255) * 2 - 1

    mask = torch.from_numpy(instance_mask).to(device).float()  # h, w
    mask = 1 - mask
    mask = mask.unsqueeze(0).unsqueeze(0)   # 1, 1, h, w
    mask = torch.nn.functional.interpolate(mask, tar_size, mode='nearest')

    image = image * mask

    ## 保存中间过程
    image_temp = torch.nn.functional.interpolate(image, (ori_h, ori_w), mode='bilinear')
    mask_temp = torch.nn.functional.interpolate(mask, (ori_h, ori_w), mode='nearest')
    image_with_mask = (image_temp + 1)*255 / 2
    image_with_mask = image_with_mask * mask_temp
    image_with_mask = image_with_mask[0].permute(1, 2, 0).detach().cpu().numpy().astype(np.uint8)  # rgb
    cv2.imwrite(image_with_mask_path, image_with_mask[:, :, ::-1])

    ##
    inpainting_model.set_input(mask, image)
    visual_dict = inpainting_model.test_forward()
    inpainting_image = visual_dict['pconv_out']
    inpainting_image = torch.nn.functional.interpolate(inpainting_image, (ori_h, ori_w), mode='bilinear')
    inpainting_image = ((inpainting_image + 1) / 2) * 255
    inpainting_image = inpainting_image[0].permute(1, 2, 0).detach().cpu().numpy().astype(np.uint8)  # rgb

    ##
    cv2.imwrite(inpainting_res_path, inpainting_image[:, :, ::-1])


    

