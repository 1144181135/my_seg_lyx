
## 安装
pip install -U openmim
mim install mmcv-full
pip install mmdet
pip install natsort

## 下载分割模型
https://download.openmmlab.com/mmdetection/v2.0/solov2/solov2_r50_fpn_3x_coco/solov2_r50_fpn_3x_coco_20220512_125856-fed092d4.pth

## demo py
demo_inference.py