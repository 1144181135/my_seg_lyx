#!/usr/bin/env python3

# Example command:
# ./bin/predict.py \
#       model.path=<path to checkpoint, prepared by make_checkpoint.py> \
#       indir=<path to input data> \
#       outdir=<where to store predicts>

import logging
import os
import sys
import traceback

import sys
pwd = os.path.abspath(os.getcwd())
sys.path.append(pwd)

from saicinpainting.evaluation.utils import move_to_device
from saicinpainting.evaluation.refinement import refine_predict
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
os.environ['NUMEXPR_NUM_THREADS'] = '1'

import cv2
from PIL import Image
import hydra
import numpy as np
import torch
import tqdm
import yaml
from omegaconf import OmegaConf
from torch.utils.data._utils.collate import default_collate

from saicinpainting.training.data.datasets import make_default_val_dataset
from saicinpainting.training.trainers import load_checkpoint
from saicinpainting.utils import register_debug_signal_handlers

LOGGER = logging.getLogger(__name__)



def ceil_modulo(x, mod):
    if x % mod == 0:
        return x
    return (x // mod + 1) * mod


def pad_img_to_modulo(img, mod):
    channels, height, width = img.shape
    out_height = ceil_modulo(height, mod)
    out_width = ceil_modulo(width, mod)
    return np.pad(img, ((0, 0), (0, out_height - height), (0, out_width - width)), mode='symmetric')


def define_inpaint_model(device, predict_config, train_config, checkpoint_path=None):
    with open(predict_config, 'r') as f:
        predict_config = OmegaConf.create(yaml.safe_load(f))
    with open(train_config, 'r') as f:
        train_config = OmegaConf.create(yaml.safe_load(f))
    train_config.training_model.predict_only = True
    train_config.visualizer.kind = 'noop'
    model = load_checkpoint(train_config, checkpoint_path, strict=False, map_location='cpu')
    model.freeze()
    if not predict_config.get('refine', False):
        model.to(device)
    return model, predict_config


def get_inpaint_res(model, image, mask, device, predict_config):
    ### image: rgb, 0~255  h,w,c
    ### mask: gray, 0~1  h,w
    ### return: rgb, 0~255   h,w,c
    image = np.transpose(image, (2, 0, 1))
    image = image.astype('float32') / 255
    mask = mask[None, ...].astype('float32')

    batch = dict()
    batch['unpad_to_size'] = image.shape[1:]
    batch['image'] = torch.from_numpy(pad_img_to_modulo(image, 8)).to(device).unsqueeze(0)
    batch['mask'] = torch.from_numpy(pad_img_to_modulo(mask, 8)).to(device).unsqueeze(0)

    with torch.no_grad():
        # batch = move_to_device(batch, device)
        batch['mask'] = (batch['mask'] > 0) * 1
        batch = model(batch)                    
        cur_res = batch[predict_config.out_key][0].permute(1, 2, 0).detach().cpu().numpy()
        unpad_to_size = batch.get('unpad_to_size', None)
        if unpad_to_size is not None:
            orig_height, orig_width = unpad_to_size
            cur_res = cur_res[:orig_height, :orig_width]

    cur_res = np.clip(cur_res * 255, 0, 255).astype('uint8')
    return cur_res



if __name__ == '__main__':


    device = 'cuda:0'
    predict_config = '/home/lyx_zy/our_code/yixinghuanying/mmtracking/demo/pred_default.yaml'
    train_config = '/home/lyx_zy/our_code/yixinghuanying/mmtracking/demo/train_default.yaml'
    checkpoint_path = None

    with open(predict_config, 'r') as f:
        predict_config = OmegaConf.create(yaml.safe_load(f))

    with open(train_config, 'r') as f:
        train_config = OmegaConf.create(yaml.safe_load(f))

    train_config.training_model.predict_only = True
    # train_config.visualizer.kind = 'noop'

    model = load_checkpoint(train_config, checkpoint_path, strict=False, map_location='cpu')
    model.freeze()
    if not predict_config.get('refine', False):
        model.to(device)
    ######################

    image = '/home/lyx_zy/our_code/yixinghuanying/mmtracking/demo/que_img.png'
    mask = '/home/lyx_zy/our_code/yixinghuanying/mmtracking/demo/que_pred.png'
    save_image = '/home/lyx_zy/our_code/yixinghuanying/mmtracking/demo/que_img_inpaint.png'

    image = Image.open(image).convert('RGB')
    mask = Image.open(mask).convert('L')

    image = np.array(image)
    image = np.transpose(image, (2, 0, 1))
    image = image.astype('float32') / 255

    mask = np.array(mask)
    if mask.max() == 255:
        mask = mask.astype('float32') / 255
    mask = mask[None, ...]

    batch = dict()
    batch['unpad_to_size'] = image.shape[1:]
    batch['image'] = torch.from_numpy(pad_img_to_modulo(image, 8)).to(device).unsqueeze(0)
    batch['mask'] = torch.from_numpy(pad_img_to_modulo(mask, 8)).to(device).unsqueeze(0)

    if predict_config.get('refine', False):
        assert 'unpad_to_size' in batch, "Unpadded size is required for the refinement"
        # image unpadding is taken care of in the refiner, so that output image
        # is same size as the input image
        cur_res = refine_predict(batch, model, **predict_config.refiner)
        cur_res = cur_res[0].permute(1,2,0).detach().cpu().numpy()   #
    else:
        print('=====')
        with torch.no_grad():
            # batch = move_to_device(batch, device)
            batch['mask'] = (batch['mask'] > 0) * 1
            batch = model(batch)                    
            cur_res = batch[predict_config.out_key][0].permute(1, 2, 0).detach().cpu().numpy()
            unpad_to_size = batch.get('unpad_to_size', None)
            if unpad_to_size is not None:
                orig_height, orig_width = unpad_to_size
                cur_res = cur_res[:orig_height, :orig_width]

    cur_res = np.clip(cur_res * 255, 0, 255).astype('uint8')
    cur_res = cv2.cvtColor(cur_res, cv2.COLOR_RGB2BGR)
    cv2.imwrite(save_image, cur_res)


