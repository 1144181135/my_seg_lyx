
from email.mime import image
from glob import glob
import torch.utils.data as data
import os
import cv2
from PIL import Image, ImageFilter
from utils import preprocess
import random
import torch
import numpy as np
from torchvision import transforms



class GaussianBlur(object):
    """Gaussian blur augmentation in SimCLR https://arxiv.org/abs/2002.05709"""

    def __init__(self, sigma=[.1, 2.]):
        self.sigma = sigma

    def __call__(self, x):
        sigma = random.uniform(self.sigma[0], self.sigma[1])
        x = x.filter(ImageFilter.GaussianBlur(radius=sigma))
        return x



class zengyi_seg(data.Dataset):
    def __init__(self, image_dir, mask_dir, split='train', tar_size=1024, transform=None):
        self.image_dir = image_dir
        self.mask_dir = mask_dir
        self.split = split

        self.resize_transform = transforms.Resize((tar_size, tar_size))
        self.transform = transform

        names = os.listdir(image_dir) if len(os.listdir(image_dir)) > len(os.listdir(mask_dir)) else os.listdir(mask_dir)
        samples = []
        for i in names:
            samples.append(i.split('.')[0])
        self.samples = samples


    def __getitem__(self, idx):
        image = os.path.join(self.image_dir, self.samples[idx]+'.jpg')
        mask = os.path.join(self.mask_dir, self.samples[idx]+'.png')

        image = Image.open(image).convert('RGB')
        mask = Image.open(mask).convert('P')
        
        image = self.resize_transform(image)
        mask = self.resize_transform(mask)

        image = self.transform(image)
        mask = np.array(mask) / 255
        mask = torch.from_numpy(mask).long()

        return image, mask


    def __len__(self):
        return len(self.samples)



def read_txt(txt):
    lines = open(txt).readlines()
    lines = [x.strip() for x in lines]
    return lines



class zengyi_seg_txt_version(data.Dataset):
    def __init__(self, image_dir, mask_dir, split='train', tar_size=1024, transform=None):
        self.image_dir = image_dir
        self.mask_dir = mask_dir
        self.split = split

        self.resize_transform = transforms.Resize((tar_size, tar_size))
        self.transform = transform

        self.data_root = '/home/lyx_zy/our_code/liuyuxuan/FSS/data/pascal/'
        self.samples = read_txt('pascal/{}.txt'.format(split))


    def __getitem__(self, idx):
        image_name, mask_name = self.samples[idx].split(' ')
        image_name = image_name.replace('JPEGImages', 'img')
        mask_name = mask_name.replace('SegmentationClassAug', 'cls')

        image = os.path.join(self.data_root, image_name)
        mask = os.path.join(self.data_root, mask_name)

        image = Image.open(image).convert('RGB')
        mask = Image.open(mask).convert('P')
        
        image = self.resize_transform(image)
        mask = self.resize_transform(mask)

        image = self.transform(image)
        mask = np.array(mask)
        mask = torch.from_numpy(mask).long()

        return image, mask


    def __len__(self):
        return len(self.samples)

