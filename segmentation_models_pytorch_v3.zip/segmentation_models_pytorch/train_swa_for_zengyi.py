import argparse
import enum
import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import pdb
from PIL import Image
from torch.autograd import Variable
from torch.optim import lr_scheduler
from torchvision import transforms
import torchvision
from lovasz_losses import lovasz_softmax
# from crops_dataset import CropSegmentation
from zengyi_dataset import zengyi_seg, GaussianBlur
from utils import AverageMeter, inter_and_union, Evaluator
#lovasz_losses
#focal loss
from PIL import Image, ImageFilter
from torchvision import transforms

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torchcontrib.optim import SWA
import torchvision_models
import segmentation_models_pytorch as smp
import efficientunet

from losses.dice_loss import DiceLoss
# os.environ["CUDA_VISIBLE_DEVICES"]='0'



class FocalLoss2d(nn.Module):
    def __init__(self, gamma=2, loss_type='softmax'):
        super(FocalLoss2d, self).__init__()
        self.gamma = gamma
        self.loss_type = loss_type

    def forward(self, logit, target):
        target[target == 255] = 0
        B, C, H, W = logit.size()
        target = target.view(-1, 1).long()
        onehot_target = torch.FloatTensor(B*H*W, C).zero_().cuda()
        onehot_target.scatter_(1, target, 1.) + 1

        logit = logit.permute(0, 2, 3, 1).contiguous().view(-1, C)
        if self.loss_type == 'sigmoid':
            prob = torch.sigmoid(logit)
        elif self.loss_type == 'softmax':
            prob = F.softmax(logit, 1)
        prob = torch.clamp(prob,1e-8,1-1e-8)

        prob = (prob * onehot_target).sum(1).view(-1,1)
        prob = torch.clamp(prob, 1e-8, 1-1e-8)
        batch_loss = - (torch.pow((1-prob), self.gamma))*prob.log()
        loss = batch_loss.mean()

        return loss


parser = argparse.ArgumentParser()
parser.add_argument('--train', action='store_true', default=True,
                    help='training mode')
# parser.add_argument('--exp', type=str, required=True,
#                     help='name of experiment')
parser.add_argument('--gpu', type=int, default=2,
                    help='test time gpu device id')
parser.add_argument('--backbone', type=str, default='resnet101',
                    help='resnet101')
parser.add_argument('--groups', type=int, default=None, 
                    help='num of groups for group normalization')
parser.add_argument('--epochs', type=int, default=30,
                    help='num of training epochs')
parser.add_argument('--batch_size', type=int, default=8,
                    help='batch size')
parser.add_argument('--base_lr', type=float, default=0.003,
                    help='base learning rate')
parser.add_argument('--last_mult', type=float, default=1.0,
                    help='learning rate multiplier for last layers')
parser.add_argument('--scratch', action='store_true', default=False,
                    help='train from scratch')
parser.add_argument('--freeze_bn', action='store_true', default=False,
                    help='freeze batch normalization parameters')
parser.add_argument('--weight_std', action='store_true', default=False,
                    help='weight standardization')
parser.add_argument('--beta', action='store_true', default=False,
                    help='resnet101 beta')
parser.add_argument('--crop_size', type=int, default=512,
                    help='image crop size')
parser.add_argument('--resume', type=str, default=None,
                    help='path to checkpoint to resume from')
parser.add_argument('--workers', type=int, default=4,
                    help='number of data loading workers')
args = parser.parse_args()

#### 要改
train_image_dir = 'demo_images'
train_mask_dir = 'demo_masks'
val_image_dir = 'demo_images'
val_mask_dir = 'demo_masks'
n_class = 21
tar_size = 320
exp_dir = 'experiments'
###

segmentation_model_version = 'torchvision'  # torchvision, smp, efficient_unet
loss_type = 'dice'  # focal, ce, dice

def main():

    assert torch.cuda.is_available()
    torch.backends.cudnn.benchmark = True

    #################################
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                    std=[0.229, 0.224, 0.225])

    transform = transforms.Compose([
        transforms.RandomApply([
            transforms.ColorJitter(0.4, 0.4, 0.4, 0.1)
        ], p=0.8),
        transforms.RandomApply([GaussianBlur([.1, 2.])], p=0.5),
        transforms.ToTensor(),
        normalize
    ])
    train_dataset = zengyi_seg(image_dir=train_image_dir, mask_dir=train_mask_dir, split='train', tar_size=tar_size, transform=transform)
    train_loader = torch.utils.data.DataLoader(
                    train_dataset, batch_size=args.batch_size, shuffle=True,
                    pin_memory=True, num_workers=args.workers)

    transform = transforms.Compose([
        transforms.ToTensor(),
        normalize
    ])
    val_dataset = zengyi_seg(image_dir=val_image_dir, mask_dir=val_mask_dir, split='val', tar_size=tar_size, transform=transform)
    val_loader = torch.utils.data.DataLoader(
                    val_dataset, batch_size=args.batch_size, shuffle=False,
                    pin_memory=True, num_workers=args.workers)
    #####################################
    
    ##### 可以换模型
    
    if segmentation_model_version == 'torchvision':
        model = torchvision_models.segmentation.deeplabv3_mobilenet_v3_large(pretrained=False, progress=True, num_classes=n_class, aux_loss=True)   # 这个模型由你自己选择 torchvision.models.segmentation 库下的
        model = model.cuda()
    
    elif segmentation_model_version == 'smp':
        model = smp.Unet(
            encoder_name="resnet50",        # choose encoder, e.g. mobilenet_v2 or efficientnet-b7
            encoder_weights="imagenet",     # use `imagenet` pre-trained weights for encoder initialization
            in_channels=n_class,                  # model input channels (1 for gray-scale images, 3 for RGB, etc.)
            classes=n_class,                      # model output channels (number of classes in your dataset)
        )
        model = model.cuda()

    elif segmentation_model_version == 'efficient_unet':
        model = efficientunet.get_efficientunet_b7(out_channels=n_class, concat_input=True, pretrained=True)
        model = model.cuda()

    ## Downloading: "https://download.pytorch.org/models/mobilenet_v3_large-8738ca79.pth" to /home/lyx_zy/.cache/torch/hub/checkpoints/mobilenet_v3_large-8738ca79.pth
    ## Downloading: "https://github.com/lukemelas/EfficientNet-PyTorch/releases/download/1.0/efficientnet-b2-8bb594d6.pth" to /home/lyx_zy/.cache/torch/hub/checkpoints/efficientnet-b2-8bb594d6.pth
    ## Downloading: "https://download.pytorch.org/models/resnet50-19c8e357.pth" to /home/lyx_zy/.cache/torch/hub/checkpoints/resnet50-19c8e357.pth
    #######

    for param in model.parameters():
        param.requires_grad = True

    optimizer1 = optim.SGD(model.parameters(), lr = args.base_lr, momentum=0.9, weight_decay=1e-4) 
    scheduler = lr_scheduler.CosineAnnealingLR(optimizer1, T_max = (args.epochs // 9) + 1)  

    # focal_loss = 
    if loss_type == 'ce':
        criterion = nn.CrossEntropyLoss(ignore_index=255)
    if loss_type == 'focal':
        criterion = FocalLoss2d()
    if loss_type == 'dice':
        criterion = DiceLoss(ignore_index=255)

    max_iou = 0
    max_epoch = -1
    
    for epoch in range(args.epochs):
        scheduler.step(epoch)
        evaluator = Evaluator(num_class=n_class)
        model, optimizer1 = train(epoch, train_loader, model, criterion, optimizer1)
        cur_iou = validate(epoch, model, val_loader, evaluator)

        is_best = cur_iou > max_iou
        if is_best:
            max_iou = cur_iou
            max_epoch = epoch

        ckpt = {
            'epoch': epoch,
            'model': model.state_dict(),
            'cur_iou': cur_iou,
            'max_iou': max_iou
        }
        if not os.path.exists(exp_dir): os.makedirs(exp_dir)

        latest = os.path.join(exp_dir, 'latest.pth')
        torch.save(ckpt, latest)

        if is_best:
            best = os.path.join(exp_dir, 'best.pth')
            torch.save(ckpt, best)

        print('>>>>> Cur Epoch: {}, cur_IOU: {:.6f}, Best_epoch: {}, max_iou: {:.6f}'.format(epoch, cur_iou, max_epoch, max_iou))



def train(epoch, train_loader, model, criterion, optimizer):
    losses = AverageMeter()

    model.train()
    for i, (inputs, target) in enumerate(train_loader):
        # print(inputs.shape, target.shape)
        # print(torch.unique(target))
        inputs = Variable(inputs.cuda())
        target = Variable(target.cuda())
        outputs = model(inputs)

        if segmentation_model_version == 'torchvision':
            loss1 = criterion(outputs['out'], target)
            loss2 = criterion(outputs['aux'], target)

            loss01 = loss1 + 0.1*loss2

            loss3 = lovasz_softmax(outputs['out'], target)
            loss4 = lovasz_softmax(outputs['aux'], target)
            loss02 = loss3 + 0.1*loss4

            loss = loss01 + loss02
        
        elif segmentation_model_version == 'smp':
            loss1 = criterion(outputs, target)
            loss2 = lovasz_softmax(outputs, target)
            loss = loss1 + loss2

        elif segmentation_model_version == 'efficient_unet':
            loss1 = criterion(outputs, target)
            loss2 = lovasz_softmax(outputs, target)
            loss = loss1 + loss2
        
        if np.isnan(loss.item()) or np.isinf(loss.item()):
            pdb.set_trace()
        
        losses.update(loss.item(), args.batch_size)

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        # if i > 10 and i % 5 == 0:
        #     optimizer.update_swa()

        print('epoch: {0}\t'
                'iter: {1}/{2}\t'
                'loss: {loss.val:.4f} ({loss.ema:.4f})'.format(
                epoch, i + 1, len(train_loader), loss=losses))

    return model, optimizer



def validate(epoch, model, val_loader, evaluator):
    model.eval()

    with torch.no_grad():
        for i, (inputs, target) in enumerate(val_loader):

            inputs = Variable(inputs.cuda())
            target = Variable(target.cuda())
            outputs = model(inputs)

            if segmentation_model_version == 'torchvision':
                outputs = outputs['out']
            else:
                outputs = outputs

            pred = outputs.detach().cpu().numpy()
            target = target.detach().cpu().numpy()
            pred = np.argmax(pred, axis=1)
            # Add batch sample into evaluator
            evaluator.add_batch(target, pred)

            string = 'Eval: Epoch: {}\t iter: {}/{}\t cur_IOU: {:.6f}'.format(epoch, i, len(val_loader), evaluator.Mean_Intersection_over_Union())
            print(string)

    mIoU = evaluator.Mean_Intersection_over_Union()
    return mIoU



                 


if __name__ == "__main__":
    main()